#pragma once
#include <deque>
#include <list>
#include <easyx.h>
#include <graphics.h>
#include <iostream>

class abstractDraw
{
public:
	virtual void show() = 0;
	virtual void setHidden(bool alpha) = 0;
	virtual bool isHidden() = 0;
};

extern std::list<abstractDraw*> overallDrawItem;
extern int DrawItemindex;
extern MOUSEMSG overallMouseMsg;
extern bool overallMouseFlag;
extern char overallKeyDown;
extern bool overallKeyFlag;

extern bool isGameStart;
extern bool isGamePause;




