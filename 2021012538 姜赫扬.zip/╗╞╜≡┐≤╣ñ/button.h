#pragma once
#include "abstractDraw.h"

class button :public abstractDraw
{
public:
	button();
	button(const char* text, int x, int y, int width, int height);

	int getId() { return id; }

	void setText(const char* text);
	void setNormalColor(COLORREF color);
	void setClickedColor(COLORREF color);
	void setPos(int x, int y) { this->x = x; this->y = y; }

	virtual void setHidden(bool alpha) { isShow = !alpha; }
	virtual bool isHidden() { return !isShow; }
	virtual void show();

	void setAction(void (*p)());
protected:
	int width = 150;
	int height = 50;
	int x = 0;
	int y = 0;

	COLORREF normalColor = RGB(245, 245, 245);
	COLORREF clickedColor = RGB(155, 155, 155);

	char* text;
	bool isClicked = false;
	//�������
	void (*p)();
	bool isAct = false;

	int id;
	bool isShow = true;
};

