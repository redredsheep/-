#include <easyx.h>

#include "Game.h"

using namespace std;


int main()
{
	Game game;
	game.show();
	return 0;
}
