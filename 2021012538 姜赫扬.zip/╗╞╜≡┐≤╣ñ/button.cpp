#include "button.h"


button::button()
{
	this->id = DrawItemindex;
	overallDrawItem.push_back(this);
	DrawItemindex++;
}

button::button(const char* text, int x, int y, int width, int height)
{
	this->text = new char[strlen(text) + 1];
	strcpy(this->text, text);
	this->text[strlen(text)] = '\0';

	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;

	this->id = DrawItemindex;
	overallDrawItem.push_back(this);
	DrawItemindex++;
}

void button::setText(const char* text)
{
	this->text = new char[strlen(text) + 1];
	strcpy(this->text, text);
	this->text[strlen(text)] = '\0';
}

void button::setNormalColor(COLORREF color)
{
	this->normalColor = color;
}

void button::setClickedColor(COLORREF color)
{
	this->clickedColor = color;
}

void button::show()
{
	if (isShow) {
		COLORREF curColor = getcolor();

		if (overallMouseMsg.x > x && overallMouseMsg.y > y && (overallMouseMsg.x < x + width) && (overallMouseMsg.y < y + height)) {
			setfillcolor(clickedColor);
			if (overallMouseFlag && overallMouseMsg.uMsg == WM_LBUTTONDOWN && isAct) {
				this->p();
			}
		}
		else if (!(overallMouseMsg.x > x && overallMouseMsg.y > y && (overallMouseMsg.x < x + width) && (overallMouseMsg.y < y + height))) {
			setfillcolor(normalColor);
		}

		solidrectangle(x, y, x + width, y + height);

		COLORREF curTextColor = gettextcolor();
		settextcolor(BLACK);
		RECT r = { x, y, x + width, y + height };
		drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		settextcolor(curTextColor);
		setfillcolor(curColor);
	}
}

void button::setAction(void (*p)())
{
	this->p = p;
	isAct = true;
}
