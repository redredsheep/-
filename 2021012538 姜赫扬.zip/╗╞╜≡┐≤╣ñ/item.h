#pragma once
#include "abstractDraw.h"

class item :public abstractDraw
{
public:
	item();
	item(int x, int y, int width, int height, const char* imgAp, const char* imgPp);
	virtual void setHidden(bool alpha) { isShow = !alpha; }
	virtual bool isHidden() { return !isShow; }
	virtual int X() { return this->x; }
	virtual int Y() { return this->y; }
	virtual int getWidth() { return this->width; }
	virtual int getHeight() { return this->height; }
	virtual void show();
	virtual void setPos(int x, int y) { this->x = x; this->y = y; }
	virtual int getScore() { return this->score; }
	void setSize(double s) { this->size = s; }
	double getSize() { return this->size; }
protected:
	int x = 0;
	int y = 0;

	int width;
	int height;

	int score;

	double size;

	IMAGE imgA;
	IMAGE imgP;

	int id;
	bool isShow = true;

};

extern std::list<item*> itemList;

