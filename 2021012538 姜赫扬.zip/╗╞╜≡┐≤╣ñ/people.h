#pragma once
#include "item.h"
class people :public item {
public:
	people(int x, int y, const char* imgAp, const char* imgPp);
	void setPos(int x, int y);
	virtual void show();
};
