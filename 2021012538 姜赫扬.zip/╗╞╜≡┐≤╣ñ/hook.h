#pragma once
#include "abstractDraw.h"
#include "item.h"

class hook :public abstractDraw
{
public:
	hook(int roleX, int roleY);
	virtual void setHidden(bool alpha) { isShow = !alpha; }
	virtual bool isHidden() { return !isShow; }
	virtual void show();
	double eX() { return this->endx; }
	double eY() { return this->endy; }
	int getState() { return this->state; }
	void setState(int state) { this->state = state; }
	void setSpeed(double sp) { this->speed = sp; }
	double Return() 
	{ return sqrt((this->endy - this->y) * (this->endy - this->y) + (this->endx - this->x) * (this->endx - this->x)); }
	void setInit();
protected:
	int id;
	bool isShow = true;

	IMAGE greper_a;
	IMAGE greper_p;

	double x;
	double y;
	double endx;
	double endy;
	int len;
	int dir;
	double angle;
	double swingSpeed;
	double speed;
	double vx;
	double vy;
	bool isSwing;
	int state;
	item* gItem;
};