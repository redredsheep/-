#include "gold.h"
gold::gold(int x, int y, int width, int height, const char* imgAp, const char* imgPp)
	:item(x, y, width, height, imgAp, imgPp)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->score = 100;
	itemList.push_back(this);
	//loadimage(&imgA, imgAp, width, height);
	//loadimage(&imgP, imgPp, width, height);
}

void gold::setPos(int x, int y)
{
	this->x = x;
	this->y = y;
}

void gold::show()
{
	if (isShow) {
		putimage(x, y, &imgA, SRCAND);
		putimage(x, y, &imgP, SRCPAINT);
	}
}

