#pragma once
#include "abstractDraw.h"
#include "button.h"
#include "gold.h"
#include "stone.h"
#include "pack.h"
#include "hook.h"
#include "item.h"
#include "people.h"
#include <conio.h>
#include <mmsystem.h>
#include <time.h>
#pragma comment (lib, "winmm.lib")
extern button* btnStart;
extern button* btnMusic;
extern button* btnSound;
extern button* btnQuit;
extern button* btnPause;
extern button* btnReStart;
extern button* btnReStartToOne;
extern bool isPlayMusic;
extern IMAGE bkImg;
extern people* peo;
extern hook* hk;
extern button* btnNextAct;
extern item* winShow;
extern item* loseShow;
extern item* bigWinShow;
extern time_t time_sec; 
extern time_t old_sec;
//��ǰ�ؿ�
extern int curAct;
//��ǰ����
extern int Score;
extern int curlasttime;
//Ĭ�� 0 ʤ�� 1 ʧ�� -1
extern int isWin;
extern int targetScore;
//��ʼ������	��һ��

void startGame();
void onMusic();
void onQuit();
void onNext();
void onPause();
void onReStart();
void onRestartToOne();
void initItem();
void showScore();
void runTime();
void showRound();
void win();
void lose();
bool distance(item* it);
//������
void debug(int k);
class Game
{
public:
	Game();
	void show();
};
