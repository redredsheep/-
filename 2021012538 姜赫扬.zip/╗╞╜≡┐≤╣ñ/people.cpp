#include "people.h"

people::people(int x, int y, const char* imgAp, const char* imgPp)
	:item(x, y, 136, 113, imgAp, imgPp)
{
	this->x = x;
	this->y = y;
	this->width = 136;
	this->height = 113;
	//itemList.push_back(this);
	this->id = DrawItemindex;
	this->setHidden(false);
	overallDrawItem.push_back(this);
	DrawItemindex++;
	//loadimage(&imgA, imgAp);
	//loadimage(&imgP, imgPp);
}

void people::setPos(int x, int y)
{
	this->x = x;
	this->y = y;
}

void people::show()
{
	if (isShow) {
		putimage(x, y, &imgA, SRCAND);
		putimage(x, y, &imgP, SRCPAINT);
	}
}