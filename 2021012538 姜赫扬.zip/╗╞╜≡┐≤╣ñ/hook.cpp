#include "hook.h"
hook::hook(int roleX, int roleY)
{
	this->id = DrawItemindex;
	this->setHidden(true);
	overallDrawItem.push_back(this);
	DrawItemindex++;

	loadimage(&greper_a, "./res/hand_a.jpg", 50, 50);
	loadimage(&greper_p, "./res/hand_p.jpg", 50, 50);

	this->x = roleX + 45;
	this->y = roleY + 90;
	this->len = 50;
	this->endx = this->x;
	this->endy = this->y + this->len;
	this->angle = 0.0;
	//left -1 right 1
	this->dir = 1;
	//���� 0 �쳤 1 ���� -1
	this->state = 0;
	this->vx = 0;
	this->vy = 0;
	this->swingSpeed = 0.25 / 3;
	this->speed = 0.75 / 3;
	this->gItem = nullptr;
}
void hook::setInit()
{
	this->x = 470 + 45;
	this->y = 30 + 90;
	this->len = 50;
	this->endx = this->x;
	this->endy = this->y + this->len;
	this->angle = 0.0;
	//left -1 right 1
	this->dir = 1;
	//���� 0 �쳤 1 ���� -1
	this->state = 0;
	this->vx = 0;
	this->vy = 0;
	this->swingSpeed = 0.25 / 3;
	this->speed = 0.75 / 3;
	this->gItem = nullptr;
}
void hook::show()
{
	if (isShow) {
		if (isGameStart&&!isGamePause) {
			if (overallKeyFlag && overallKeyDown == 32 && this->state == 0)
				this->state = 1;
			this->vx = sin(3.1415 / 180 * this->angle) * (this->speed);
			this->vy = cos(3.1415 / 180 * this->angle) * (this->speed);
			//std::cout << "speed:" << this->speed << std::endl;
		}
		if (this->endx <= 0 || this->endx >= 1080 || this->endy >= 640)
		{
			this->state = -1;
		}

		if (this->state == 0 && !isGamePause)
		{
			if (this->dir == 1)
			{
				this->angle += this->swingSpeed;
			}
			else
			{
				this->angle -= this->swingSpeed;
			}
			if (this->angle > 80)
			{
				this->dir = -1;
			}
			else if (this->angle < -80)
			{
				this->dir = 1;
			}
			this->endx = this->x + sin(3.1415 / 180 * this->angle) * this->len;
			this->endy = this->y + cos(3.1415 / 180 * this->angle) * this->len;
		}
		else if (this->state == 1 && !isGamePause) {
			this->endx += this->vx;
			this->endy += this->vy;
		}
		else if (this->state == -1 && !isGamePause) {
			this->endx -= this->vx;
			this->endy -= this->vy;
			//������̵�ԭ���ĳ��ȣ���ֹͣ���̣��ж�����ĩ�˵ľ����Ƿ���ڣ�����
			if (this->Return() <= this->len)
			{
				this->state = 0;
				this->speed = 0.75/3;
			}
		}

		LINESTYLE curStyle;
		getlinestyle(&curStyle);
		COLORREF curColor = getlinecolor();

		setlinestyle(PS_SOLID, 5);
		setlinecolor(BROWN);
		line(this->x, this->y, this->endx, this->endy);

		//circle(this->endx, this->endy, 3);
		putimage(this->endx - 25, this->endy, &greper_a, SRCAND);
		putimage(this->endx - 25, this->endy, &greper_p, SRCPAINT);

		setlinestyle(&curStyle);
		setlinecolor(curColor);
	}
}