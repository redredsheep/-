#include "pack.h"
#include <time.h>
pack::pack(int x, int y, int width, int height, const char* imgAp, const char* imgPp)
	:item(x, y, width, height, imgAp, imgPp)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	srand(time(NULL));
	itemList.push_back(this);
	//loadimage(&imgA, imgAp, width, height);
	//loadimage(&imgP, imgPp, width, height);
}

void pack::setPos(int x, int y)
{
	this->x = x;
	this->y = y;
}

void pack::show()
{
	if (isShow) {
		this->score = 10 * (rand() % 9 + 1) + 30;

		putimage(x, y, &imgA, SRCAND);
		putimage(x, y, &imgP, SRCPAINT);
	}
}