#include "abstractDraw.h"

std::list<abstractDraw*> overallDrawItem;
int DrawItemindex = 0;
MOUSEMSG overallMouseMsg;
bool overallMouseFlag = false;
char overallKeyDown;
bool overallKeyFlag = false;

bool isGameStart = false;

bool isGamePause = false;



