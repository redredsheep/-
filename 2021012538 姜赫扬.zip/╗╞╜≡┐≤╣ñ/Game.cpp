#include "Game.h"

button* btnStart;
button* btnMusic;
button* btnSound;
button* btnQuit;
button* btnPause;
button* btnReStart;
button* btnReStartToOne;
bool isPlayMusic = false;
IMAGE bkImg;
people* peo;
hook* hk;

button* btnNextAct;

item* winShow;
item* loseShow;
item* bigWinShow;

time_t time_sec = 0;       //time_t�൱��long int
time_t old_sec = 0;
int curAct = 0;
//��ǰ����
int Score = 0;
int isWin = 0;
int curlasttime = 70;
//Ŀ�����
int targetScore = 200;

namespace game0 {
	gold* g0;
	gold* g1;
	gold* g2;

	stone* s0;
	stone* s1;
	stone* s2;

	pack* p0;
	pack* p1;
}
namespace game1 {
	gold* g0;
	gold* g1;
	gold* g2;

	stone* s0;
	stone* s1;
	stone* s2;

	pack* p0;
	pack* p1;
}
namespace game2 {
	gold* g0;
	gold* g1;
	gold* g2;

	stone* s0;
	stone* s1;
	stone* s2;

	pack* p0;
	pack* p1;
}

Game::Game()
{
	initgraph(1080, 640, EW_SHOWCONSOLE);
	setbkmode(TRANSPARENT);
	setbkcolor(WHITE);
	loadimage(&bkImg, "./res/bk.jpg");

	winShow = new item(1080 / 2 - 565 / 2, 640 / 2 - 409 / 2,565,409, "./res/victory_a.jpg", "./res/victory_p.jpg");
	loseShow = new item(1080 / 2 - 490 / 2, 640 / 2 - 567 / 2,490,567, "./res/defeat_a.jpg", "./res/defeat_p.jpg");
	bigWinShow = new item(1080 / 2 - 551*1.5 / 2, 640 / 2 - 312*1.5 / 2, 551*1.5, 312*1.5, "./res/bigWin.jpeg", "");

	btnStart = new button("��ʼ��Ϸ", (1080-150)/2, 640/2-100, 150, 50);
	btnStart->setNormalColor(RGB(211, 154, 83));
	btnStart->setClickedColor(RGB(140, 84, 35));
	btnStart->setAction(startGame);

	btnMusic = new button("�ر�����", (1080 - 150) / 2, 640 / 2 - 100+50+10, 150, 50);
	btnMusic->setNormalColor(RGB(211, 154, 83));
	btnMusic->setClickedColor(RGB(140, 84, 35));
	btnMusic->setAction(onMusic);

	btnReStartToOne = new button("���¿�ʼ", (1080 - 150) / 2, 640 / 2 - 100 + 50*2 + 10*2, 150, 50);
	btnReStartToOne->setNormalColor(RGB(211, 154, 83));
	btnReStartToOne->setClickedColor(RGB(140, 84, 35));
	btnReStartToOne->setHidden(false);
	btnReStartToOne->setAction(onRestartToOne);

	btnQuit = new button("�˳���Ϸ", (1080 - 150) / 2, 640 / 2 - 100 + 50*3 + 10*3, 150, 50);
	btnQuit->setNormalColor(RGB(211, 154, 83));
	btnQuit->setClickedColor(RGB(140, 84, 35));
	btnQuit->setAction(onQuit);

	btnNextAct= new button("��һ��", (1080 - 150) / 2, 640 / 2 - 100 + 50 * 2 + 10 * 2, 150, 50);
	btnNextAct->setNormalColor(RGB(211, 154, 83));
	btnNextAct->setClickedColor(RGB(140, 84, 35));
	btnNextAct->setHidden(true);
	btnNextAct->setAction(onNext);

	btnPause = new button("��ͣ", 10+700, 80, 150, 50);
	btnPause->setNormalColor(RGB(211, 154, 83));
	btnPause->setClickedColor(RGB(140, 84, 35));
	btnPause->setHidden(true);
	btnPause->setAction(onPause);

	btnReStart = new button("���¿�ʼ", 10 + 700, 80, 150, 50);
	btnReStart->setNormalColor(RGB(211, 154, 83));
	btnReStart->setClickedColor(RGB(140, 84, 35));
	btnReStart->setHidden(true);
	btnReStart->setAction(onReStart);
	

	initItem();

	mciSendString("open ./res/bgm.mp3 alias bgm", NULL, 0, NULL);
	mciSendString("play bgm repeat", NULL, 0, NULL);
	isPlayMusic = true;
}

void Game::show()
{
	BeginBatchDraw();
	while (1) {
		overallKeyFlag = false;
		overallMouseFlag = false;

		putimage(0, 0, &bkImg);

		COLORREF curLineColor = getfillcolor();
		setlinecolor(BLACK);
		fillrectangle(0, 140, 1080, 143);
		setfillcolor(curLineColor);

		if (_kbhit()) {
			overallKeyFlag = true;
			overallKeyDown = _getch();
		}

		if (MouseHit()) {
			overallMouseMsg = GetMouseMsg();
			overallMouseFlag = true;
		}

		if (!isGamePause) {
			for (std::list<item*>::iterator it = itemList.begin(); it != itemList.end(); it++) {
				if ((*it)->isHidden()) {
					continue;
				}
				if (distance(*it) && (*it)->isHidden() == false) {
					if (hk->getState() == 1) {
						//hk->setSpeed(0.75);
						hk->setState(-1);
						std::cout << "size:" << (*it)->getSize() << std::endl;
						hk->setSpeed((*it)->getSize() * 0.75 / 3);
					}
					//hk->setSpeed((*it)->getSize() * 0.75);
					(*it)->setPos(hk->eX() - 25, hk->eY());

					//std::cout << hk->Return() << std::endl;

					int abs_len = abs(hk->eY() - (*it)->Y());

					if (hk->Return() <= 50) {
						(*it)->setHidden(true);
						//�ӷ�
						Score += (*it)->getScore();
					}
				}
			}
		}
			for (std::list<abstractDraw*>::iterator it = overallDrawItem.begin(); it != overallDrawItem.end(); it++) {
				if ((*it)->isHidden()) {
					continue;
				}
				(*it)->show();
			}

		if (isGameStart&&isWin==0) {
			showScore();
			runTime();
		}

		if (isWin != 0) {
			hk->setHidden(true);
			if (isWin == 1) {
				win();
			}
			else if (isWin == -1) {
				lose();
			}
		}

		showRound();

		debug(1);

		FlushBatchDraw();
		cleardevice();
	}
	EndBatchDraw();
	closegraph();
}

void startGame()
{
	std::cout << "��Ϸ��ʼ" << std::endl;
	//���ذ�ť
	btnStart->setHidden(true);
	btnMusic->setHidden(true);
	btnQuit->setHidden(true);
	btnReStartToOne->setHidden(true);
	btnPause->setHidden(false);

	isGameStart = true;
	isGamePause = false;
}

void onMusic()
{
	if (!btnMusic->isHidden() && isPlayMusic) {
		std::cout << "���ֹر���..." << std::endl;
		btnMusic->setText("������");
		mciSendString("pause bgm", NULL, 0, NULL);
		isPlayMusic = false;
		std::cout << "���ֹر�" << std::endl;
	}
	else {
		std::cout << "���ִ�" << std::endl;
		btnMusic->setText("�ر�����");
		mciSendString("resume bgm", NULL, 0, NULL);
		isPlayMusic = true;
		std::cout << "���ֲ�����..." << std::endl;	
	}
}

void onQuit()
{
	exit(0);
}

void onPause()
{
	std::cout << "��Ϸ��ͣ" << std::endl;
	//���ذ�ť
	btnStart->setHidden(false);
	btnStart->setText("������Ϸ");
	btnMusic->setHidden(false);
	btnQuit->setHidden(false);
	btnReStartToOne->setHidden(false);
	btnPause->setHidden(true);
	isGameStart = false;
	isGamePause = true;
}

void onReStart()
{
	std::cout << "���¿�ʼ" << std::endl;
	//itemList.clear();

	btnReStart->setHidden(true);
	isGameStart = true;
	isWin = 0;
	Score = 0;
	hk->setHidden(false);
	bigWinShow->setHidden(true);
	winShow->setHidden(true);
	loseShow->setHidden(true);
	btnNextAct->setHidden(true);
	btnPause->setHidden(false);
	hk->setInit();

	if (curAct == 0) {
		targetScore = 200;
		curlasttime = 70;

		game0::g0->setPos(100, 400);
		game0::g1->setPos(748, 472);
		game0::g2->setPos(371, 261);
		game0::s0->setPos(500, 550);
		game0::s1->setPos(700, 405);
		game0::s2->setPos(905, 585);
		game0::p0->setPos(800, 300);
		game0::p1->setPos(70, 320);

		game0::g0->setScore(150);
		game0::g1->setScore(100);
		game0::g2->setScore(80);

		game0::g0->setSize(0.3);
		game0::g1->setSize(0.7);
		game0::g2->setSize(1);
		game0::s0->setSize(1);
		game0::s1->setSize(1);
		game0::s2->setSize(1);
		game0::p0->setSize(0.1);
		game0::p1->setSize(0.1);

		game0::g0->setHidden(false);
		game0::g1->setHidden(false);
		game0::g2->setHidden(false);
		game0::s0->setHidden(false);
		game0::s1->setHidden(false);
		game0::s2->setHidden(false);
		game0::p0->setHidden(false);
		game0::p1->setHidden(false);
		game1::g0->setHidden(true);
		game1::g1->setHidden(true);
		game1::g2->setHidden(true);
		game1::s0->setHidden(true);
		game1::s1->setHidden(true);
		game1::s2->setHidden(true);
		game1::p0->setHidden(true);
		game1::p1->setHidden(true);
		game2::g0->setHidden(true);
		game2::g1->setHidden(true);
		game2::g2->setHidden(true);
		game2::s0->setHidden(true);
		game2::s1->setHidden(true);
		game2::s2->setHidden(true);
		game2::p0->setHidden(true);
		game2::p1->setHidden(true);
	}else if (curAct == 1) {
		targetScore = 300;
		curlasttime = 60;

		game1::g0->setPos(200, 350);
		game1::g1->setPos(600, 512);
		game1::g2->setPos(150, 272);
		game1::s0->setPos(100, 550);
		game1::s1->setPos(600, 289);
		game1::s2->setPos(841, 300);
		game1::p0->setPos(500, 550);
		game1::p1->setPos(280, 450);

		game1::g0->setScore(80);
		game1::g1->setScore(180);
		game1::g2->setScore(100);

		game1::g0->setSize(0.7);
		game1::g1->setSize(0.3);
		game1::g2->setSize(1);
		game1::s0->setSize(1);
		game1::s1->setSize(1);
		game1::s2->setSize(1);
		game1::p0->setSize(0.1);
		game1::p1->setSize(0.1);

		game1::g0->setHidden(false);
		game1::g1->setHidden(false);
		game1::g2->setHidden(false);
		game1::s0->setHidden(false);
		game1::s1->setHidden(false);
		game1::s2->setHidden(false);
		game1::p0->setHidden(false);
		game1::p1->setHidden(false);
		game0::g0->setHidden(true);
		game0::g1->setHidden(true);
		game0::g2->setHidden(true);
		game0::s0->setHidden(true);
		game0::s1->setHidden(true);
		game0::s2->setHidden(true);
		game0::p0->setHidden(true);
		game0::p1->setHidden(true);
		game2::g0->setHidden(true);
		game2::g1->setHidden(true);
		game2::g2->setHidden(true);
		game2::s0->setHidden(true);
		game2::s1->setHidden(true);
		game2::s2->setHidden(true);
		game2::p0->setHidden(true);
		game2::p1->setHidden(true);

	}
	else if (curAct == 2) {
		targetScore = 400;
		curlasttime = 50;

		game2::g0->setPos(480, 500);
		game2::g1->setPos(900, 256);
		game2::g2->setPos(300, 544);
		game2::s0->setPos(800, 255);
		game2::s1->setPos(300, 149);
		game2::s2->setPos(420, 250);
		game2::p0->setPos(250, 500);
		game2::p1->setPos(560, 225);

		game2::g0->setScore(120);
		game2::g1->setScore(180);
		game2::g2->setScore(100);
		game2::s0->setScore(40);
		game2::s1->setScore(30);

		game2::g0->setSize(0.45);
		game2::g1->setSize(0.2);
		game2::g2->setSize(0.5);
		game2::s0->setSize(0.8);
		game2::s1->setSize(0.7);
		game2::s2->setSize(1);
		game2::p0->setSize(0.1);
		game2::p1->setSize(0.1);

		game2::g0->setHidden(false);
		game2::g1->setHidden(false);
		game2::g2->setHidden(false);
		game2::s0->setHidden(false);
		game2::s1->setHidden(false);
		game2::s2->setHidden(false);
		game2::p0->setHidden(false);
		game2::p1->setHidden(false);
		game0::g0->setHidden(true);
		game0::g1->setHidden(true);
		game0::g2->setHidden(true);
		game0::s0->setHidden(true);
		game0::s1->setHidden(true);
		game0::s2->setHidden(true);
		game0::p0->setHidden(true);
		game0::p1->setHidden(true);
		game1::g0->setHidden(true);
		game1::g1->setHidden(true);
		game1::g2->setHidden(true);
		game1::s0->setHidden(true);
		game1::s1->setHidden(true);
		game1::s2->setHidden(true);
		game1::p0->setHidden(true);
		game1::p1->setHidden(true);
	}
}

void onRestartToOne()
{
	std::cout << "��Ϸ���¿�ʼ" << std::endl;
	//���ذ�ť
	btnStart->setHidden(true);
	btnMusic->setHidden(true);
	btnQuit->setHidden(true);
	btnReStartToOne->setHidden(true);
	btnPause->setHidden(false);

	isGameStart = true;
	isGamePause = false;
	curAct = 0;
	onReStart();
}

void initItem()
{
	peo = new people(1080 / 2 - 140 / 2, 30, "./res/people_a.jpg", "./res/people_p.jpg");
	peo->setHidden(false);

	hk = new hook(1080 / 2 - 140 / 2, 30);
	hk->setHidden(false);

	game0::g0 = new gold(100, 400, 179, 161, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game0::g1 = new gold(748, 472, 179 * 0.8, 161 * 0.8, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game0::g2 = new gold(371, 261, 179 * 0.5, 161 * 0.5, "./res/gold_a.jpg", "./res/gold_p.jpg");
	

	game0::s0 = new stone(500, 550, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game0::s1 = new stone(700, 405, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game0::s2 = new stone(905, 585, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");

	game0::p0 = new pack(800, 300,54,61, "./res/pack_a.jpg", "./res/pack_p.jpg");
	game0::p1 = new pack(70, 320,54,61, "./res/pack_a.jpg", "./res/pack_p.jpg");

	game0::g0->setScore(150);
	game0::g1->setScore(100);
	game0::g2->setScore(80);

	game0::g0->setSize(0.3);
	game0::g1->setSize(0.7);
	game0::g2->setSize(1);
	game0::s0->setSize(1);
	game0::s1->setSize(1);
	game0::s2->setSize(1);
	game0::p0->setSize(0.1);
	game0::p1->setSize(0.1);

	game0::g0->setHidden(false);
	game0::g1->setHidden(false);
	game0::g2->setHidden(false);
	game0::s0->setHidden(false);
	game0::s1->setHidden(false);
	game0::s2->setHidden(false);
	game0::p0->setHidden(false);
	game0::p1->setHidden(false);

	game1::g0 = new gold(200, 350, 179 * 0.7, 161 * 0.7, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game1::g1 = new gold(600, 512, 179, 161, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game1::g2 = new gold(150, 272, 179 * 0.5, 161 * 0.5, "./res/gold_a.jpg", "./res/gold_p.jpg");

	game1::s0 = new stone(100, 550, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game1::s1 = new stone(600, 289, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game1::s2 = new stone(841, 300, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");

	game1::p0 = new pack(500, 550, 54, 61, "./res/pack_a.jpg", "./res/pack_p.jpg");
	game1::p1 = new pack(280, 450, 54, 61, "./res/pack_a.jpg", "./res/pack_p.jpg");

	game1::g0->setScore(80);
	game1::g1->setScore(180);
	game1::g2->setScore(100);

	game1::g0->setSize(0.7);
	game1::g1->setSize(0.3);
	game1::g2->setSize(1);
	game1::s0->setSize(1);
	game1::s1->setSize(1);
	game1::s2->setSize(1);
	game1::p0->setSize(0.1);
	game1::p1->setSize(0.1);

	game1::g0->setHidden(true);
	game1::g1->setHidden(true);
	game1::g2->setHidden(true);
	game1::s0->setHidden(true);
	game1::s1->setHidden(true);
	game1::s2->setHidden(true);
	game1::p0->setHidden(true);
	game1::p1->setHidden(true);


	game2::g0 = new gold(480, 500, 179 * 0.65, 161 * 0.65, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game2::g1 = new gold(900, 256, 179 * 0.8, 161 * 0.8, "./res/gold_a.jpg", "./res/gold_p.jpg");
	game2::g2 = new gold(300, 544, 179 * 0.4, 161 * 0.4, "./res/gold_a.jpg", "./res/gold_p.jpg");

	game2::s0 = new stone(800, 255, 62 * 1.5, 52 * 1.5, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game2::s1 = new stone(300, 149, 62 * 1.1, 52 * 1.1, "./res/stone_a.jpg", "./res/stone_p.jpg");
	game2::s2 = new stone(420, 250, 62, 52, "./res/stone_a.jpg", "./res/stone_p.jpg");

	game2::p0 = new pack(250, 500, 54, 61, "./res/pack_a.jpg", "./res/pack_p.jpg");
	game2::p1 = new pack(560, 225, 54, 61, "./res/pack_a.jpg", "./res/pack_p.jpg");


	game2::g0->setScore(120);
	game2::g1->setScore(180);
	game2::g2->setScore(100);
	game2::s0->setScore(40);
	game2::s1->setScore(30);

	game2::g0->setSize(0.45);
	game2::g1->setSize(0.2);
	game2::g2->setSize(0.5);
	game2::s0->setSize(0.8);
	game2::s1->setSize(0.7);
	game2::s2->setSize(1);
	game2::p0->setSize(0.1);
	game2::p1->setSize(0.1);

	game2::g0->setHidden(true);
	game2::g1->setHidden(true);
	game2::g2->setHidden(true);
	game2::s0->setHidden(true);
	game2::s1->setHidden(true);
	game2::s2->setHidden(true);
	game2::p0->setHidden(true);
	game2::p1->setHidden(true);

	//itemList.push_back(game0::g0);
	//itemList.push_back(game0::g1);
	//itemList.push_back(game0::g2);
	//itemList.push_back(game0::s0);
	//itemList.push_back(game0::s1);
	//itemList.push_back(game0::s2);
	//itemList.push_back(game0::p0);
	//itemList.push_back(game0::p1);
}

bool distance(item* it)
{
	if (hk->eX()+25+3 > it->X() && hk->eY()+3 > it->Y() 
		&& (hk->eX() < it->X() + it->getWidth()-3) && (hk->eY() < it->Y() + it->getHeight()-3)) {
		return true;
	}
	return false;
}
void showScore()
{
	COLORREF curColor = getcolor();
	COLORREF curTextColor = gettextcolor();

	settextcolor(WHITE);
	RECT r = { 10, 10, 10 + 150, 10 + 50 };
	char text[256];

	sprintf(text, "������%d", Score);

	drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	settextcolor(curTextColor);
	setfillcolor(curColor);
}
void showRound()
{
	COLORREF curColor = getcolor();
	COLORREF curTextColor = gettextcolor();

	settextcolor(WHITE);
	RECT r = { 120, 10, 10 + 120 + 150, 10 + 50 };
	char text[256];
	if (curAct == 0&&isGameStart&&isWin==0) {
		sprintf(text, "Round1");

		drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	else if (curAct == 1 && isGameStart && isWin == 0) {
		sprintf(text, "Round2");

		drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}
	else if (curAct == 2 && isGameStart && isWin == 0) {
		sprintf(text, "Round3");

		drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	settextcolor(curTextColor);
	setfillcolor(curColor);
}
void runTime() {
	
	old_sec = time_sec;
	if (Score >= targetScore) {
		isWin = 1;
	}

	if (curlasttime > 0&&isWin==0)
	{
		time(&time_sec);          //��ȡ��ǰ������1970-1-1 00:00:00�����ڣ�,Ȼ���������浽time_t����
		if (time_sec != old_sec)   //��������ı䣨��ʱ�ﵽ1�룩
		{
			old_sec = time_sec;   //���¾ɵ�����
			if (curlasttime > 0)
				curlasttime--;            //��ʱ������1
		}
	}
	else if(curlasttime <= 0) {
		isWin = -1;	
	}
	COLORREF curColor = getcolor();
	COLORREF curTextColor = gettextcolor();

	settextcolor(WHITE);
	RECT r = { 10 + 850, 10, 10 + 850+200, 10 + 80 };
	char text[256];

	sprintf(text, "ʱ�䣺%d", curlasttime);

	drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	settextcolor(curTextColor);
	setfillcolor(curColor);
}

void win() {
	//565 409
	if (curAct >= 2) {
		bigWinShow->setHidden(false);
		btnReStart->setPos(10, 140 - 50 - 10);
		btnNextAct->setHidden(true);
		//btnPause->setHidden(false);
	}
	else if (curAct < 2 ) {
		winShow->setHidden(false);
		btnNextAct->setPos(10, 140 - 50 - 10);
		btnNextAct->setHidden(false);
		btnReStart->setPos(200, 140 - 50 - 10);
	}
	btnReStart->setHidden(false);
	//btnPause->setHidden(true);
	hk->setInit();
}
void lose() {
	//490 567
	loseShow->setHidden(false);
	btnReStart->setPos(200, 140 - 50 - 10);
	btnReStart->setHidden(false);
	btnPause->setHidden(true);
	btnNextAct->setHidden(true);
	hk->setInit();
}
void onNext()
{
	curAct++;
	game0::g0->setHidden(true);
	game0::g1->setHidden(true);
	game0::g2->setHidden(true);
	game0::s0->setHidden(true);
	game0::s1->setHidden(true);
	game0::s2->setHidden(true);
	game0::p0->setHidden(true);
	game0::p1->setHidden(true);

	isWin = 0;
	hk->setHidden(false);
	bigWinShow->setHidden(true);
	winShow->setHidden(true);
	loseShow->setHidden(true);
	btnNextAct->setHidden(true);
	btnReStart->setHidden(true);
	btnPause->setHidden(false);

	if (curAct == 1) {

		Score = 0;
		targetScore = 300;
		curlasttime = 60;

		game1::g0->setPos(200, 350);
		game1::g1->setPos(600, 512);
		game1::g2->setPos(150, 272);
		game1::s0->setPos(100, 550);
		game1::s1->setPos(600, 289);
		game1::s2->setPos(841, 300);
		game1::p0->setPos(500, 550);
		game1::p1->setPos(280, 450);

		game1::g0->setHidden(false);
		game1::g1->setHidden(false);
		game1::g2->setHidden(false);
		game1::s0->setHidden(false);
		game1::s1->setHidden(false);
		game1::s2->setHidden(false);
		game1::p0->setHidden(false);
		game1::p1->setHidden(false);
		game0::g0->setHidden(true);
		game0::g1->setHidden(true);
		game0::g2->setHidden(true);
		game0::s0->setHidden(true);
		game0::s1->setHidden(true);
		game0::s2->setHidden(true);
		game0::p0->setHidden(true);
		game0::p1->setHidden(true);
		game2::g0->setHidden(true);
		game2::g1->setHidden(true);
		game2::g2->setHidden(true);
		game2::s0->setHidden(true);
		game2::s1->setHidden(true);
		game2::s2->setHidden(true);
		game2::p0->setHidden(true);
		game2::p1->setHidden(true);

		//itemList.push_back(game1::g0);
		//itemList.push_back(game1::g1);
		//itemList.push_back(game1::g2);
		//itemList.push_back(game1::s0);
		//itemList.push_back(game1::s1);
		//itemList.push_back(game1::s2);
		//itemList.push_back(game1::p0);
		//itemList.push_back(game1::p1);
	}
	else if (curAct == 2) {

		Score = 0;
		targetScore = 400;
		curlasttime = 50;

		game2::g0->setPos(480, 500);
		game2::g1->setPos(900, 256);
		game2::g2->setPos(300, 544);
		game2::s0->setPos(800, 255);
		game2::s1->setPos(300, 149);
		game2::s2->setPos(420, 250);
		game2::p0->setPos(250, 500);
		game2::p1->setPos(560, 225);

		game2::g0->setHidden(false);
		game2::g1->setHidden(false);
		game2::g2->setHidden(false);
		game2::s0->setHidden(false);
		game2::s1->setHidden(false);
		game2::s2->setHidden(false);
		game2::p0->setHidden(false);
		game2::p1->setHidden(false);
		game0::g0->setHidden(true);
		game0::g1->setHidden(true);
		game0::g2->setHidden(true);
		game0::s0->setHidden(true);
		game0::s1->setHidden(true);
		game0::s2->setHidden(true);
		game0::p0->setHidden(true);
		game0::p1->setHidden(true);
		game1::g0->setHidden(true);
		game1::g1->setHidden(true);
		game1::g2->setHidden(true);
		game1::s0->setHidden(true);
		game1::s1->setHidden(true);
		game1::s2->setHidden(true);
		game1::p0->setHidden(true);
		game1::p1->setHidden(true);

		//itemList.push_back(game2::g0);
		//itemList.push_back(game2::g1);
		//itemList.push_back(game2::g2);
		//itemList.push_back(game2::s0);
		//itemList.push_back(game2::s1);
		//itemList.push_back(game2::s2);
		//itemList.push_back(game2::p0);
		//itemList.push_back(game2::p1);
	}

	if (curAct > 2) {
		curAct = 0;
	}

}
void debug(int k)
{
	if (overallKeyFlag && overallKeyDown == 27) {
		Score += 1000;
	}
}