#pragma once
#include "item.h"

class stone :public item {
public:
	stone(int x, int y, int width, int height, const char* imgAp, const char* imgPp);
	void setPos(int x, int y);
	virtual void show();
	virtual int getScore() { return this->score; }
	void setScore(int s) { this->score = s; }
};

