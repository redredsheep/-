#include "item.h"
std::list<item*> itemList;


item::item()
{
	this->id = DrawItemindex;
	this->setHidden(true);
	overallDrawItem.push_back(this);
	DrawItemindex++;
}

item::item(int x, int y, int width, int height, const char* imgAp, const char* imgPp)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	loadimage(&imgA, imgAp, width, height);
	loadimage(&imgP, imgPp, width, height);
	this->id = DrawItemindex;
	this->setHidden(true);
	overallDrawItem.push_back(this);
	DrawItemindex++;
}

void item::show()
{
	if (isShow) {
		putimage(x, y, &imgA, SRCAND);
		putimage(x, y, &imgP, SRCPAINT);
	}
}
