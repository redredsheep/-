#include "stone.h"
stone::stone(int x, int y, int width, int height, const char* imgAp, const char* imgPp)
	:item(x, y, width, height, imgAp, imgPp)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->score = 20;
	itemList.push_back(this);
	//loadimage(&imgA, imgAp, width, height);
	//loadimage(&imgP, imgPp, width, height);
}

void stone::setPos(int x, int y)
{
	this->x = x;
	this->y = y;
}

void stone::show()
{
	if (isShow) {
		putimage(x, y, &imgA, SRCAND);
		putimage(x, y, &imgP, SRCPAINT);
	}
}